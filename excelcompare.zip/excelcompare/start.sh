#!/usr/bin/env bash
# Start the easyexcel-compare application from the extracted folder.
cd "$(dirname "$0")" || exit 1
# "." keeps ./config/excelcompare.properties and ./data on the classpath so that
# spring.config.import=classpath:/config/excelcompare.properties is picked up.
exec java -cp ".;bootstrap/easyexcel-compare-0.0.1.jar" io.md2java.easyexcel.EasyexcelcomparatorApplication "$@"
