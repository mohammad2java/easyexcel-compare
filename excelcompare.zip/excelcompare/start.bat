@echo off
rem Start the easyexcel-compare application from the extracted folder.
cd /d "%~dp0"
java -cp ".;bootstrap/easyexcel-compare-0.0.1.jar" io.md2java.easyexcel.EasyexcelcomparatorApplication %*
